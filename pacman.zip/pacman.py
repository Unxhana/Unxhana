from ast import Module
import random
from pygame import *
# from pygame.locals import *
from random import randint
from PIL import Image
import pygame
import sys


pygame.init()


window = display.set_mode((900, 770))
display.set_caption("pacman")

pygame_icon = pygame.image.load('logo.png')
pygame.display.set_icon(pygame_icon)


map = transform.scale(image.load("black.jpg"),(900, 770))
bg = transform.scale(image.load("bgg.png"),(900, 770))
mog = transform.scale(image.load("win.jpg"),(900, 770))
gameov = transform.scale(image.load("gaov.png"),(900, 770))



color = (0,255,255)


mixer.init()
mixer.music.load("game_start.wav")
mixer.music.set_volume(0.54)
mixer.music.play()  


run = True
finish = False
clock = time.Clock()
FPS = 60
score = 0
main_menu = True
Win = True

# restart = image.load('restart_btn.png')
# start_img = image.load('script\start_btn.png')
# exit_img = image.load('script\exit_btn.png')



pointFont = pygame.font.Font("JosefinSans-Bold.ttf", 15)
point = pointFont.render(str(score), True, "white", "black")
pointRect = point.get_rect()
pointRect.center = (410, 400)


highsFont = pygame.font.Font('JosefinSans-Bold.ttf', 15)
highs = highsFont.render(str(score), True, 'white', 'black')
highsRect = highs.get_rect()
highsRect.center = (410, 415)


pygame.time.wait(2000)





class WallX(sprite.Sprite):
    
    def __init__(self, width, height, color, x, y, random=False):
        super().__init__()
        self.w = width
        self.h = height
        self.name = WallX.__name__
        self.color=color
        self.visible = True

        if random:
            self.x=randint(0,700-100)
            self.y=randint(0,500-100)
        self.sur = Surface((self.w, self.h))
        self.rect = self.sur.get_rect()
        self.rect.x = x
        self.rect.y = y


    def draw_wall(self):
        draw.rect(window,self.color,Rect(self.rect.x, self.rect.y, self.w, self.h))

    def hide(self):
        if self.visible:
            window.blit(window, (self.rect.x, self.rect.y))



#kutxeebi
w1 = WallX(10, 900, color, 0, 0)
w2 = WallX(10, 900, color, 890, 0)
w3 = WallX(900, 10, color, 0, 763)
w4 = WallX(900, 10, color, 0, 0)


#vertikaluri kedlebi
w5 = WallX(15, 80, color, 450, 0)
w6 = WallX(15, 80, color, 450, 180)
w7 = WallX(15, 80, color, 370, 360)
w8 = WallX(15, 80, color, 530, 360)
w9 = WallX(15, 160, color, 280, 360)
w10 = WallX(15, 160, color, 620, 360)
w11 = WallX(15, 160, color, 800, 520)
w12 = WallX(15, 160, color, 80, 520)
w13 = WallX(15, 80, color, 450, 600)
w14 = WallX(15, 160, color, 80, 180)
w15 = WallX(15, 160, color, 800, 180)
w16 = WallX(15, 160, color, 160, 260)
w17 = WallX(15, 160, color, 720, 260)

w18 = WallX(15, 30, color, 80, 763)
w19 = WallX(15, 30, color, 800, 763)


#horizontaluri kedlebi
h1 = WallX(300, 15, color, 80, 90)
h2 = WallX(290, 15, color, 530, 90)
h3 = WallX(85, 15, color, 90, 180)
h4 = WallX(80, 15, color, 720, 180)
h5 = WallX(360, 15, color, 280, 180)
h6 = WallX(135, 15, color, 160, 260)
h7 = WallX(110, 15, color, 620, 260)
h8 = WallX(160, 15, color, 370, 360)
h9 = WallX(175, 15, color, 370, 440)
h10 = WallX(355, 15, color, 280, 510)
h11 = WallX(355, 15, color, 280, 600)
h12 = WallX(200, 15, color, 160, 680)
h13 = WallX(200, 15, color, 540, 680)
h14 = WallX(85, 15, color, 10, 415)
h15 = WallX(85, 15, color, 80, 510)
h16 = WallX(95, 15, color, 800, 415)

YELLOW = (255, 255, 222)

class Food(sprite.Sprite):
    def __init__(self,x,y,radius):
        sprite.Sprite.__init__(self)
        self.x = x
        self.y = y
        self.size = 10
        self.color = YELLOW
        self.radius = radius
        self.surface = Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
        self.rect = self.surface.get_rect(center=(x, y))
        self.visible = True
        
    def paint(self, plus_x=0, plus_y=0):
        draw.circle(window, YELLOW, [self.x + plus_x, self.y + plus_y], 5, 0)
    
    def hide(self):
        self.visible = False



# def generate_food(num_food):
#     food_list = []
#     for _ in range(num_food):
#         x = random.randint(0, 900 - 10)
#         y = random.randint(0, 770 - 10)
#         food = Food(x,y)
#         food_list.append(food)
#     return food_list

# def game_loop():
#     num_food = 15
#     food_list = generate_food(num_food)






class GameSprite(sprite.Sprite):
    #class constructor
    def __init__(self, player_image, player_x, player_y, player_speed):
        super().__init__()
 
        #every sprite must store the image property
        self.image = transform.scale(image.load(player_image), (45, 45))
        self.sec = transform.scale(image.load("sec.png"), (45,45)) 
        self.orig = transform.flip(self.image, False, False)
        self.flip = transform.flip(self.image, True, False)
        self.up = transform.flip(self.image, False, True)
        self.up = transform.rotate(self.up,90)
        self.down = transform.flip(self.image, False, True)
        self.down = transform.rotate(self.down, 270)
        self.speed = player_speed
        #every sprite must have the rect property – the rectangle it is fitted in
        self.rect = self.image.get_rect()
        self.rect.x = player_x
        self.rect.y = player_y
        self.visible = True
        self.direction = 0
        self.cost = 0
        self.y_velocity = 0
        self.dire = 'nun'

    def update(self):

        if sprite.spritecollide(mainnigga, bgroup, False):
            if self.dire == "right" :
                self.rect.x -= 5
            if self.dire == 'down':
                self.rect.y -= 5
            if self.dire == 'up':
                self.rect.y += 5
            if self.dire == 'left':
                self.rect.x += 5




        keys = key.get_pressed()
        if keys[K_d] and self.rect.x < 850:
            self.dire = 'right'
            self.image = self.orig
            self.rect.x += self.speed
            
        if keys[K_a] and self.rect.x > 10:
            self.dire = 'left'
            self.image = self.orig
            self.image = self.flip
            self.rect.x -= self.speed
            self.rect.x = self.rect.x

        if keys[K_s] and self.rect.y > 10:
            self.dire = "down"
            self.image = self.down
            self.rect.y += self.speed


        if keys[K_w] and self.rect.y > 15:
            self.dire = "up"
            self.direction = 1
            self.rect.y -= self.speed

            if self.direction == 1:
                self.image = self.up



        # if keys[K_SPACE]:
        #     self.visible = True
        #     self.rect.x = 100
        #     self.rect.y = 130
            


        if self.dire == 'right' and self.dire == 'up':
            self.rect.x -= 2
            self.rect.y -= 2

        if self.dire == 'down' and self.dire == 'left':
            self.rect.x -= 2
            self.rect.y -= 2




    def reset(self):
        if self.visible:
            window.blit(self.image, (self.rect.x, self.rect.y))

    # def show(self):
    #     window.blit(self.imagefile,(self.rect.x,self.rect.y))



class Button():
    def __init__(self,image_path,w,h,x,y):
        sprite.Sprite.__init__(self)
        self.imagefile = transform.scale(image.load(image_path),(w,h))
        self.rect = self.imagefile.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.clicked = False


    def draw(self):
        action = False
        pos = pygame.mouse.get_pos()
        if self.rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                action = True
                self.clicked = True
                
        if pygame.mouse.get_pressed()[0] == 0:
            self.clicked = False


        window.blit(self.imagefile, self.rect)

        return action

class Enemy(GameSprite):
    def update(self):
        keys = key.get_pressed()

        if keys[K_j]:
            self.rect.x += self.speed
        if keys[K_h]:
            self.rect.x -= self.speed


class Enemy(GameSprite):
    side = 'down'
    def update(self, yy, y):

        if self.rect.y <= yy:
            self.side = 'down'

        if self.rect.y >= y:
            self.side = "up"


        if self.side == 'up':
            self.rect.y -= self.speed
        if self.side == "down":
            self.rect.y += self.speed





class SecEnemy(GameSprite):
    side = 'right' #xx - starting point, x - finish point
    def mupdate(self, start, finish):
        if self.rect.x == start + 5:
            self.side = "right"
        
        if self.rect.x == finish -5:
            self.side = "left"

        if self.side == "right" and self.rect.x < finish:
            self.rect.x += 1
            
        if self.side == "left" and self.rect.x > start:
            self.rect.x -= 1
        
#         if self.rect.x >= 10:
#             self.side = "right"
        
#         if self.rect.x == 300:
#             self.side = "left"

#         if self.side == "right":
#             self.rect.x += self.speed
#         if self.side == "left":
#             self.rect.x -= self.speed







class Map(sprite.Sprite):
    def __init__(self,image_path,w,h,x=0,y=0):
        sprite.Sprite.__init__(self)
        self.imagefile = transform.scale(image.load(image_path),(w,h))
        self.rect = self.imagefile.get_rect()
        self.rect.x = x
        self.rect.y = y

    def reset(self):
        window.blit(self.imagefile, (self.rect.x, self.rect.y))





mainnigga = GameSprite('main.png',100,130,5)



red = Enemy('red.png',830,20,4)
blue = Enemy('blue.png', 100, 300, 4)
cyan = SecEnemy("powerup.png",50 ,700, 10)

start_button = Button('start_btn.png',280, 125, 900 // 2 -300, 740 // 2 - 50)
exit_button = Button('exit_btn.png',240, 126,900 // 2 + 100, 740 // 2 - 50)





group = sprite.Group()
group.add(w1, w2, w3, w4, w5, w6, w7, w8, w9, w10, w11, w12, w13, w14, w15, w16, w17)
hgroup = sprite.Group()
hgroup.add(h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15, h16)


bgroup = sprite.Group()
bgroup.add(group, hgroup)


pgroup = sprite.Group()


nigga = sprite.Group()
nigga.add(mainnigga)


krazy = sprite.Group()
krazy.add(red)
krazy.add(blue)
krazy.add(cyan)




#horizontaluri sachmlebi


for i in range(15):
    plus_x = i * 50
    plus_y = i* 50
    w = Map("circ.png", 10, 10, 95 + plus_x, 140)
    pgroup.add(w)
    

for m in range(11):
    pluss_x = m * 50
    r = Map("circ.png", 10, 10, 190 + pluss_x, 300)
    pgroup.add(r)

for z in range(14):
    vav_x = z * 50
    t = Map("circ.png", 10, 10, 110 + vav_x, 560)
    pgroup.add(t)

for o in range(5):
    plius_x = o * 50
    y = Map("circ.png", 10, 10, 40 + plius_x, 460 )
    u = Map("circ.png", 10, 10, 650 + plius_x, 460)
    pgroup.add(y)
    pgroup.add(u)

for p in range(7):
    pplus_x = p * 50
    f = Map("circ.png", 10, 10, 95 + pplus_x, 40)
    k = Map("circ.png", 10, 10, 500 + pplus_x, 40)
    p = Map("circ.png", 10, 10, 120 + pplus_x, 220)
    l = Map("circ.png", 10, 10, 450 + pplus_x, 220)
    a = Map("circ.png", 10, 10, 115 + pplus_x, 640)
    s = Map("circ.png", 10, 10, 480 + pplus_x, 640)
    d = Map("circ.png", 10, 10, 300 + pplus_x, 475)
    pgroup.add(p)
    pgroup.add(f)
    pgroup.add(k)
    pgroup.add(l)
    pgroup.add(a)
    pgroup.add(s)
    pgroup.add(d)

for g in range(17):
    lplus_X = g * 50
    f = Map("circ.png", 10, 10, 45 + lplus_X, 720)
    pgroup.add(f)


#vertikaluri sachmlebi


for h in range(8):
    vplus_y = h * 50
    k = Map("circ.png", 10, 10, 40, 40 + vplus_y)
    l = Map("circ.png", 10, 10, 850, 40 + vplus_y)
    pgroup.add(k)
    pgroup.add(l)

for v in range(4):
    v_y = v * 50
    a = Map("circ.png", 10, 10, 40, 520 + v_y)
    s = Map("circ.png", 10, 10, 850, 520 + v_y)
    pgroup.add(a)
    pgroup.add(s)

for j in range(3):
    vv_y = j * 50
    a = Map("circ.png", 10, 10, 120, 270 + vv_y)
    b = Map("circ.png", 10, 10, 760, 270 + vv_y)
    pgroup.add(a)
    pgroup.add(b)

for t in range(2):
    f_y = t * 50
    a = Map("circ.png", 10, 10, 220, 350 + f_y)
    b = Map("circ.png", 10, 10, 670, 350 + f_y)
    c = Map("circ.png", 10, 10, 325, 360 + f_y)
    d = Map("circ.png", 10, 10, 585, 360 + f_y)
    pgroup.add(a)
    pgroup.add(b)
    pgroup.add(c)
    pgroup.add(d)


highs_surf = highsFont.render('high score: ' + str(score), True, 'white', 'black')
window.blit(highs_surf, highsRect)


while run:


    for e in event.get():
        if e.type == QUIT:
            run = False

        else:
            finish = False
    
    if finish != True:
        if main_menu == True:
            window.blit(bg, (0, 0))
            if exit_button.draw():
                run = False
            if start_button.draw():
                main_menu = False




        else:
            window.blit(map, (0, 0))
            for i in pgroup:
                i.reset()
            mainnigga.reset()
            mainnigga.update()  

            red.reset()
            red.update(20, 360)

            blue.reset()
            blue.update(200, 460)

            cyan.reset()
            cyan.mupdate(20, 760)




            if sprite.groupcollide(nigga, pgroup,False, True):
                mixer.music.load('munch_2.wav') 
                mixer.music.play()
                # window.blit(point, pointRect)
                score += 1
                mixer.music.load('munch_1.wav')
                mixer.music.play()

            if sprite.groupcollide(nigga, krazy, True, False):
                mixer.music.load('death_1.wav') 
                mixer.music.play()
                mainnigga.visible = False
                # pygame.time.wait(5000)
                score = 0
                
                

            # for food in food_list:
            #     food.draw(window)
        
            score_surf = pointFont.render("score: " + str(score), True, "white", "black")
            window.blit(score_surf, pointRect)

            if score > 0 and main_menu == False :
                highs_surf = highsFont.render('high score: ' + str(score), True, 'white', 'black')

            window.blit(highs_surf, highsRect)
            
            


                # highs_surf = highsFont.render('high score: ' + str(score), True, 'white', 'black')
                


            w1.draw_wall()
            w2.draw_wall()
            w3.draw_wall()
            w4.draw_wall()
            w5.draw_wall()
            w6.draw_wall()
            w7.draw_wall()
            w8.draw_wall()
            w9.draw_wall()
            w10.draw_wall()
            w11.draw_wall()
            w12.draw_wall()
            w13.draw_wall()
            w14.draw_wall()
            w15.draw_wall()
            w16.draw_wall()
            w17.draw_wall()
            w18.draw_wall()
            w19.draw_wall()

            h1.draw_wall()
            h2.draw_wall()
            h3.draw_wall()
            h4.draw_wall()
            h5.draw_wall()
            h6.draw_wall()
            h7.draw_wall()
            h8.draw_wall()
            h9.draw_wall()
            h10.draw_wall()
            h11.draw_wall()
            h12.draw_wall()
            h13.draw_wall()
            h14.draw_wall()
            h15.draw_wall()
            h16.draw_wall()
            if score >= 153:
                window.blit(mog, (0, 0))
                mixer.music.pause()
                mainnigga.kill()

                w1, w2, w3, w4, w5, w6, w7, w8, w9, w10, w11, w12, w13, w14, w15, w16, w17,h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15, h16.hide()
            if score == 0:
                window.blit(gameov, (0, 0))
                
            display.flip()
            display.update()

    display.flip()
    display.update()
    clock.tick(FPS)

